/*********************************************************************************\
|     FACULDADE DE ENGENHARIA DE RESENDE - FER                                    |
|     PROJETO DE MICROPROCESSADORES - ALARME RESIDENCIAL MICROCONTROLADO          |
|                                                                                 |
|     DESENVOLVEDORES:   MARIA ANT�NIA OLIVEIRA RODRIGUES               13270009  |
|                         JAMILE DOS SANTOS SILVA MIRANDA               14270120  |
|                         VINICIUS RODRIGUES DE OLIVEIRA                13270094  |
|                         YAN DE PAULA VASCONCELLOS                     13270012  |
|                         LUCAS CAVALLOTTI CARVALHO                     13270064  |
|                                                                                 |
|                                                                                 |
|   "Projetar sistema de alarme residencial contendo ao menos dois dispositivos de|
|presen�a de infravermelho, dois sensores de abertura de porta/janela e sirene.   |
|Al�m disso deve dispor de teclado para incluir senha de armar/desarmar.          |
|                                                                                 |
|                                                                                 |
\*********************************************************************************/


/////////////////////////BIBLIOTECA DO LCD/////////////////////////////////////////

// Lcd pinout settings
sbit LCD_RS at RD2_bit;
sbit LCD_EN at RD3_bit;
sbit LCD_D7 at RD7_bit;
sbit LCD_D6 at RD6_bit;
sbit LCD_D5 at RD5_bit;
sbit LCD_D4 at RD4_bit;

// Pin direction
sbit LCD_RS_Direction at TRISD2_bit;
sbit LCD_EN_Direction at TRISD3_bit;
sbit LCD_D7_Direction at TRISD7_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D4_Direction at TRISD4_bit;


/////////////////////PROGRAMA��O DO TECLADO MATRICIAL/////////////////////////////

// --- Hardware ---
#define col_1   RB1_bit
#define col_2   RB2_bit
#define col_3   RB3_bit
#define row_A   RB4_bit
#define row_B   RB5_bit
#define row_C   RB6_bit
#define row_D   RB7_bit


char control = 0x01;                                //Variavel para fazer a varredura no teclado
char number = 'a';                                  //Variavel para armazenar o digito do teclado
                                                    //Variavel moment�nea

void interrupt()                                    //Varredura do teclado por interrup��o
{
    if(T0IF_bit)                                    //Houve estouro do Timer0?
    {                                               //Sim...



      if(col_1 && control == 0x01)                  //Coluna 1 em n�vel high? Control igual 1?
      {                                             //Sim...
         control = 0x02;
         col_1 = 0x01;                              //Apenas a coluna 1 em n�vel alto
         col_2 = 0x00;
         col_3 = 0x00;

         if(row_A)      number='1';                 //O nivel alto da coluna vai aparecer na linha que for pressionada
         else if(row_B) number='4';
         else if(row_C) number='7';
         else if(row_D) ;

         col_1 = 0x00;
         col_2 = 0x01;
         
                                                     //Variavel momentanea para n�o gerar duplica��o do digito

      }

      else if(col_2 && control == 0x02)              //Coluna 2 em n�vel high? Control igual 2?
      {                                              //Sim...

         control = 0x03;
         col_1 = 0x00;                               //Apenas a coluna 2 em n�vel alto
         col_2 = 0x01;
         col_3 = 0x00;

         if(row_A)      number='2';                  //O nivel alto da coluna vai aparecer na linha que for pressionada
         else if(row_B) number='5';
         else if(row_C) number='8';
         else if(row_D) number='0';
         
         col_2 = 0x00;
         col_3 = 0x01;
         
                                                    //Variavel momentanea para n�o gerar duplica��o do digito

      }
      else if(col_3 && control == 0x03)             //Coluna 3 em n�vel high? Control igual 3?
      {                                             //Sim...
         control = 0x01;
         col_1 = 0x00;                              //Apenas a coluna 3 em n�vel alto
         col_2 = 0x00;
         col_3 = 0x01;

         if(row_A)      number='3';                 //O nivel alto da coluna vai aparecer na linha que for pressionada
         else if(row_B) number='6';
         else if(row_C) number='9';
         else if(row_D) ;
         
         col_3 = 0x00;
         col_1 = 0x01;
         
                                                     //Variavel momentanea para n�o gerar duplica��o do digito

      }
      
      T0IF_bit = 0x00;                              //Limpa a flag
      TMR0     = 0x6C;                              //Reinicia o timer0


    }

} //end interrupt


//////////////////////////PROGRAMA PRINCIPAL/////////////////////////////////////////////////////////

int counter=1;                            //Contador
char testasenha[4];                       //Vari�vel para testar a senha correta
int senhaok[4] ={'1','2','5','6'};        //Vari�vel para armazenar a senha correta
int i=0;                                  //Vari�vel idicadora de senha correta
int e=0;                                  //Vari�vel idicadora de senha errada


// --- Fun��o Principal
void main()
{
     CMCON      = 0x07;                   //Desabilita os comparadores
     OPTION_REG = 0x86;                   //Timer0 incrementa com ciclo de instru��o, prescaler 1:128
     GIE_bit    = 0x01;                   //Habilita interrup��o global
     PEIE_bit   = 0x01;                   //Habilita interrup��o por perif�ricos
     T0IE_bit   = 0x01;                   //Habilita interru��o do Timer0

     TMR0       = 0x6C;                   //Inicia o timer0

     TRISA = 0x02;                        //Entrada em RA0 e RA1
     TRISB = 0xF0;                        //Nibble mais significativo do PORTB ser� entrada
     TRISD = 0x00;                        //PortD todo ser� saida
     TRISC = 0x0F;                        //Nibble mais significativo do PortC ser� sa�da
     
     PORTD = 0x00;                        //Portd come�a em low
     PORTA = 0x05;                        //RA0 e RA2 iniciam em high
     PORTB = 0x0F;                        //Nibble mais significativo inicia em low.
     PORTC = 0x03;                        //RC0 e RC1 Come�a em high

    Lcd_Init();                           // Inicializa Display
    Lcd_Cmd(_LCD_CURSOR_OFF);             //Apaga o cursor
    Lcd_Cmd(_LCD_CLEAR);                  // Limpa o display

     while(1)                             //Loop Infinito
     {

      Lcd_out(1,1,"Digite a Senha");      //Indicador para digitar a senha
      delay_ms(10);                       //Led piscando indicando que o programa esta funcionado
      RD0_bit = 1;
      delay_ms(200);
      RD0_bit = 0;
      delay_ms(200);

      
      if (number!='a' && counter<= 4)     // Loop de if para imprimir o numero no display e testar a senha correta
         {                                // S� testa a senha quaso o number tiver algum valor que sera dado pelo teclado

         Lcd_Chr(2,counter,number);      // Imprime na tela do lcd o numero na coluna igual ao valor do contador
         testasenha[counter] = number;   // Copia o numero para a variavel testasenha para que o programa verifique

         if(counter == 1 && testasenha[1] == '1' ) {i++;}   // caso testasenha[1] igual a 1 i � incrementado
         if(counter == 1 && testasenha[1] != '1' ) {e++;}   // caso testasenha[1] diferente de 1 � � incrementado
         
         if(counter == 2 && testasenha[2] == '2' ) {i++;}   // caso testasenha[2] igual a 2 i � incrementado
         if(counter == 2 && testasenha[2] != '2' ) {e++;}   // caso testasenha[2] diferente de 2 � � incrementado
         
         if(counter == 3 && testasenha[3] == '5' ) {i++;}   // caso testasenha[3] igual a 5 i � incrementado
         if(counter == 3 && testasenha[3] != '5' ) {e++;}   // caso testasenha[3] diferente de 5 � � incrementado
         
         if(counter == 4 && testasenha[4] == '6' ) {i++;}   // caso testasenha[4] igual a 6 i � incrementado
         if(counter == 4 && testasenha[4] != '6' ) {e++;}   // caso testasenha[4] diferente de 6 � � incrementado
         
          number='a';                                       // Number volta a ser um valor qualquer
                                                            // Number momentaneo volta a ser um valor qualquer
          counter++;                                        // Incrementa o contador
         }
         if(counter == 5 && e>=1)                           // Se o contador for igual a 5, ou seja, o usur�rio....
          {                                                 // ..ja digitou 4 digitos e a variavel "e" foi incrementada..
           lcd_out(2,5," Senha Errada");                     // ...quer dizer que ao menos um digito estava errado
           RD1_bit=1;
          }
         if(i==4)                                           //Se a cada teste o i foi incrementado, seu valor ser� 4...
          {                                                 //... ent�o a senha esta correta
           lcd_out(2,5," Alarme ON");
           RD0_bit=1;
           
             while(i==4)                                                   //Rotina dos sensores
             {                                                             //Sensor de presen�a ativado = Nivel alto
                                                                           //Sensor magn�tico ativado = Nivel baixo
               if(RC0_bit == 0||RC1_bit == 0 ||RC2_bit == 1||RC3_bit == 1) //Caso um dos sensores ativarem a sirene toca
               {
                RC7_bit = 1;
               }
             }
          }

     } //end while
} //end main