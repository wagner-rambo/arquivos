//
//  ViewController.swift
//  Calculadora
//
//  Created by Guilherme Rambo on 06/05/16.
//  Copyright © 2016 Guilherme Rambo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak private var display: UILabel!
    
    private var digitandoNumero = false
    
    @IBAction private func digito(sender: UIButton) {
        if digitandoNumero {
            display.text = display.text! + sender.currentTitle!
        } else {
            display.text = sender.currentTitle!
            digitandoNumero = true
        }
    }
    
    private var valorAtual: Double {
        get {
            return Double(display.text!)!
        }
        set {
            display.text = String(newValue)
        }
    }
    
    private var calculadora = Calculadora()
    
    @IBAction private func operacao(sender: UIButton) {
        if digitandoNumero {
            calculadora.adicionarOperando(valorAtual)
        }
        
        digitandoNumero = false
        
        if let simbolo = sender.currentTitle {
            calculadora.executarOperacao(simbolo)
        }
        
        valorAtual = calculadora.resultado
    }
}

