//
//  Calculadora.swift
//  Calculadora
//
//  Created by Guilherme Rambo on 06/05/16.
//  Copyright © 2016 Guilherme Rambo. All rights reserved.
//

import Foundation

class Calculadora {
    
    private enum Operacao {
        case Constante(Double)
        case Unaria((Double) -> (Double))
        case Binaria((Double, Double) -> Double)
        case Igual
    }
    
    private struct DadosDeOperacaoBinaria {
        var operando: Double
        var funcao: (Double, Double) -> Double
    }
    
    private var operacaoEmAndamento: DadosDeOperacaoBinaria?
    
    private var operacoes = [
        "π": Operacao.Constante(M_PI),
        "e": Operacao.Constante(M_E),
        "√": Operacao.Unaria(sqrt),
        "cos": Operacao.Unaria(cos),
        "×": Operacao.Binaria(*),
        "+": Operacao.Binaria(+),
        "÷": Operacao.Binaria(/),
        "−": Operacao.Binaria(-),
        "=": Operacao.Igual
    ]
    
    func adicionarOperando(operando: Double) {
        resultadoParcial = operando
    }
    
    func executarOperacao(operacao: String) {
        guard let operacao = operacoes[operacao] else { return }
        
        switch operacao {
        case .Constante(let valor):
            resultadoParcial = valor
        case .Unaria(let funcao):
            resultadoParcial = funcao(resultadoParcial)
        case .Binaria(let funcao):
            executarOperacaoEmAndamento()
            operacaoEmAndamento = DadosDeOperacaoBinaria(operando: resultadoParcial, funcao: funcao)
        case .Igual:
            executarOperacaoEmAndamento()
        }
    }
    
    private func executarOperacaoEmAndamento() {
        if operacaoEmAndamento != nil {
            resultadoParcial = operacaoEmAndamento!.funcao(operacaoEmAndamento!.operando, resultadoParcial)
            operacaoEmAndamento = nil
        }
    }
    
    private var resultadoParcial = 0.0
    
    var resultado: Double {
        get {
            return resultadoParcial
        }
    }
    
}