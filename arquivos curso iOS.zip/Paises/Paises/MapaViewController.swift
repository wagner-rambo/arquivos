//
//  MapaViewController.swift
//  Paises
//
//  Created by Guilherme Rambo on 06/05/16.
//  Copyright © 2016 Guilherme Rambo. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapaViewController: UIViewController {

    var pais: String? {
        didSet {
            mostraPais()
        }
    }
    
    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        mostraPais()
    }
    
    func mostraPais() {
        guard let pais = pais else { return }
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(pais) { place, error in
            guard error == nil else { return } // falha
            guard let placemarks = place else { return } // nada encontrado
            guard placemarks.count > 0 else { return } // nada encontrado
            guard let location = placemarks[0].location else { return } // regiao invalida
            
            let region = MKCoordinateRegion(center: location.coordinate, span: MKCoordinateSpan(latitudeDelta: 30, longitudeDelta: 30))
            dispatch_async(dispatch_get_main_queue()) {
                self.mapa.setRegion(region, animated: true)
            }
        }
        
        title = pais
    }

    @IBAction func fechar(sender: UIBarButtonItem) {
        parentViewController?.dismissViewControllerAnimated(true, completion: nil)
    }
}
