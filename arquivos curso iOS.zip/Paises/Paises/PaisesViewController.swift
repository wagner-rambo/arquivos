//
//  PaisesViewController.swift
//  Paises
//
//  Created by Guilherme Rambo on 06/05/16.
//  Copyright © 2016 Guilherme Rambo. All rights reserved.
//

import UIKit

class PaisesViewController: UITableViewController {

    struct Constants {
        static let listaDePaises = "https://pastebin.com/raw/MazdSGQk"
    }
    
    var paises: [String]? {
        didSet {
            mostrarPaises()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        refreshControl = UIRefreshControl()
        refreshControl?.attributedTitle = NSAttributedString(string: "Atualizar Lista")
        refreshControl?.addTarget(self, action: #selector(atualizar), forControlEvents: .ValueChanged)
        
        atualizar()
    }

    func atualizar() {
        refreshControl?.beginRefreshing()
        
        let session = NSURLSession(configuration: NSURLSessionConfiguration.defaultSessionConfiguration())
        session.dataTaskWithURL(NSURL(string: Constants.listaDePaises)!) { data, response, error in
            guard let data = data else { return } // falha
            guard error == nil else { return } // falha
            
            guard let lista = String(data: data, encoding: NSUTF8StringEncoding) else { return } // falha
            
            dispatch_async(dispatch_get_main_queue()) {
                self.refreshControl?.endRefreshing()
                self.paises = lista.componentsSeparatedByString("\r\n")
            }
            }.resume()
    }
    
    func mostrarPaises() {
        guard paises != nil else { return }
        
        tableView.reloadData()
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return paises != nil ? paises!.count : 0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("pais")
        
        cell?.textLabel?.text = paises![indexPath.row]
        
        return cell!
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "abrirPais" {
            guard let paisVC = segue.destinationViewController as? PaisViewController else { return }
            paisVC.pais = paises![tableView.indexPathForSelectedRow!.row]
        }
    }


}

