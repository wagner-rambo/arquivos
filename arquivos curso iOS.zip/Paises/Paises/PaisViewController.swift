//
//  PaisViewController.swift
//  Paises
//
//  Created by Guilherme Rambo on 06/05/16.
//  Copyright © 2016 Guilherme Rambo. All rights reserved.
//

import UIKit

class PaisViewController: UIViewController {

    struct Constants {
        static let URLWikipedia = "https://pt.wikipedia.org/wiki/"
    }
    
    var pais: String? {
        didSet {
            mostraPais()
        }
    }
    
    @IBOutlet weak var webView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        mostraPais()
    }
    
    func mostraPais() {
        guard webView != nil else { return }
        guard let pais = pais else { return }
        
        title = pais
        
        let paisCodificado = pais.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLPathAllowedCharacterSet())!
        let URL = NSURL(string: "\(Constants.URLWikipedia)\(paisCodificado)")!
        webView.loadRequest(NSURLRequest(URL: URL))
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "verMapa" {
            guard let mapaVC = (segue.destinationViewController as? UINavigationController)?.viewControllers[0] as? MapaViewController else { return }
            mapaVC.pais = pais
        }
    }

}
